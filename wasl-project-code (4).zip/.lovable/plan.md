
## نظرة عامة
خطة شاملة لتفعيل المميزات المطلوبة مع إصلاح ذاتي للأخطاء وتحسين الأداء.

## 1. عرض المنشورات (صور + نصوص) في كل الصفحات
- التأكد من أن `PostCard` يعرض `image_url` والنص معاً (مع fallback أنيق).
- في `feed.tsx`: عرض كل المنشورات (نصية + بصور) مرتبة زمنياً.
- في `profile.tsx`: نفس المكوّن `PostCard` لمنشورات المستخدم.
- في `marketplace.tsx`: شريط أعلى الصفحة بآخر المنشورات (مصغّر).
- في `messages.tsx`: لا تغيير (محادثات فقط).

## 2. نظام الأصدقاء (طلب/قبول/رفض)
**قاعدة بيانات** (migration جديد):
- جدول `friendships`: `requester_id`, `addressee_id`, `status` (pending/accepted/rejected), `created_at`.
- RLS: الطرفان يريان السجل، المرسل ينشئ، المستلم يحدّث الحالة.
- GRANT للـ authenticated و service_role.

**واجهات**:
- `src/lib/friends.functions.ts`: `sendRequest`, `respondRequest`, `listFriends`, `listIncoming`, `removeFriend`.
- صفحة جديدة `src/routes/friends.tsx` بتبويبات: أصدقائي / طلبات واردة / طلبات صادرة.
- زر «إضافة صديق / قبول / إلغاء» في `profile.tsx` بجانب «رسالة».
- شارة عدد الطلبات الواردة في `Header`.

## 3. البحث برقم الهاتف داخل التطبيق
- إضافة عمود `phone` (text, nullable) إلى `profiles` + index.
- حقل رقم الهاتف في تحرير الملف الشخصي (اختياري).
- توسيع `searchUsers` لتقبل البحث برقم الهاتف بجانب الاسم/المعرّف.
- في `messages.tsx` (الإنبوكس): توضيح أن البحث يدعم رقم الهاتف.

## 4. تفعيل المتجر فعلياً
- إضافة دالة DB `purchase_listing(_listing_id)`: تخصم النقاط من المشتري، تضيفها للبائع، تُنشئ رسالة تلقائية للبائع تحتوي على تفاصيل الطلب.
- زر «اشترِ الآن بالنقاط» في `marketplace.$listingId.tsx` يستدعي serverFn جديد.
- إشعار toast + إعادة توجيه إلى المحادثة مع البائع.

## 5. الأصوات (TTS + تعليقات صوتية + محادثة AI)
- **TTS للتعليقات والإشعارات** عبر ElevenLabs:
  - serverFn جديد `src/lib/tts.functions.ts` يستدعي ElevenLabs ويعيد audio (base64 data URI).
  - زر 🔊 بجانب كل تعليق نصي ومحتوى المنشور في `PostCard`.
- **التعليق الصوتي**: `AudioRecorder` موجود مسبقاً — التأكد من ظهوره ضمن نموذج التعليق ورفعه إلى bucket `voice-comments` + حفظ `audio_url` في `comments`.
- **محادثة صوتية مباشرة مع AI Agent**:
  - استخدام `@elevenlabs/react` (`useConversation`) + WebRTC.
  - serverFn `getElevenLabsToken` يُولّد conversation token.
  - يتطلب من المستخدم إنشاء Agent في ElevenLabs ولصق `agent_id` (نطلب secret `ELEVENLABS_AGENT_ID`).
  - تحديث `VoiceChat.tsx` ليستخدم الـ Agent الحقيقي بدل النص.

## 6. تحسين تلقائي بالذكاء الاصطناعي (الخوارزميات + الأداء)
- إضافة جدول `app_health_logs` لتسجيل الأخطاء من `error-capture.ts`.
- serverFn يومي `analyzeHealth` يستدعي Gemini لتحليل آخر الأخطاء واقتراح تحسينات (يُسجَّل كـ insights مرئية للمسؤول فقط، لا تعديل تلقائي للكود — هذا غير ممكن في وقت التشغيل).
- تحسين خوارزمية الـ feed: ترتيب حسب (التفاعلات الأخيرة + أصدقاء + بلد) عبر serverFn `getRankedFeed`.

## 7. الصفحة الرئيسية شاملة
- `feed.tsx` يعرض: منشورات (نصية + صور) + شريط فيديوهات أعلى + شريط متجر مصغّر + `NewsPanel` + اقتراحات أصدقاء.

## ترتيب التنفيذ
1. migration: `friendships` + `phone` + `app_health_logs` + دالة `purchase_listing`.
2. خوادم: `friends.functions.ts`, `tts.functions.ts`, `marketplace.functions.ts`, `feed.functions.ts`.
3. واجهات: `friends.tsx`, تحديث `profile/feed/marketplace/PostCard/VoiceChat/Header`.
4. طلب secret `ELEVENLABS_AGENT_ID` قبل ربط المحادثة الصوتية.

## ملاحظات تقنية
- نستخدم Lovable AI Gateway لتحليل الأخطاء (Gemini Flash).
- نستخدم ElevenLabs (موجود `ELEVENLABS_API_KEY`) للـ TTS والمحادثة.
- كل serverFn محمي بـ `requireSupabaseAuth`.
- لا تعديل لـ `client.ts` أو `types.ts` (يُولَّد تلقائياً).
